/*
 Navicat Premium Data Transfer

 Source Server         : Mysql
 Source Server Type    : MySQL
 Source Server Version : 50549
 Source Host           : localhost:3306
 Source Schema         : pstore

 Target Server Type    : MySQL
 Target Server Version : 50549
 File Encoding         : 65001

 Date: 12/01/2019 22:07:44
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_admin
-- ----------------------------
DROP TABLE IF EXISTS `tb_admin`;
CREATE TABLE `tb_admin`  (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`uid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_admin
-- ----------------------------
INSERT INTO `tb_admin` VALUES (1, 'Kira', 'e10adc3949ba59abbe56e057f20f883e');
INSERT INTO `tb_admin` VALUES (2, 'Sakvoi', '4d430028a6cf42c8802d311c2ca7904b');

-- ----------------------------
-- Table structure for tb_category
-- ----------------------------
DROP TABLE IF EXISTS `tb_category`;
CREATE TABLE `tb_category`  (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`cid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_category
-- ----------------------------
INSERT INTO `tb_category` VALUES (1, '手机');
INSERT INTO `tb_category` VALUES (2, '台式机');
INSERT INTO `tb_category` VALUES (3, '平板·笔记本');
INSERT INTO `tb_category` VALUES (4, '电视');
INSERT INTO `tb_category` VALUES (5, '盒子·影音');
INSERT INTO `tb_category` VALUES (6, '路由器');
INSERT INTO `tb_category` VALUES (7, '智能硬件');
INSERT INTO `tb_category` VALUES (9, '耳机音箱');
INSERT INTO `tb_category` VALUES (10, '生活箱包');
INSERT INTO `tb_category` VALUES (11, '健康儿童');
INSERT INTO `tb_category` VALUES (14, '其他');

-- ----------------------------
-- Table structure for tb_categorysecond
-- ----------------------------
DROP TABLE IF EXISTS `tb_categorysecond`;
CREATE TABLE `tb_categorysecond`  (
  `csid` int(50) NOT NULL AUTO_INCREMENT,
  `csname` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cid` int(50) NULL DEFAULT NULL,
  PRIMARY KEY (`csid`) USING BTREE,
  INDEX `cid`(`cid`) USING BTREE,
  CONSTRAINT `cid` FOREIGN KEY (`cid`) REFERENCES `tb_category` (`cid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_categorysecond
-- ----------------------------
INSERT INTO `tb_categorysecond` VALUES (1, '小米手机', 1);
INSERT INTO `tb_categorysecond` VALUES (2, '魅族手机', 1);
INSERT INTO `tb_categorysecond` VALUES (3, '三星', 1);
INSERT INTO `tb_categorysecond` VALUES (4, 'apple', 1);
INSERT INTO `tb_categorysecond` VALUES (5, '华硕笔记本电脑', 3);
INSERT INTO `tb_categorysecond` VALUES (6, '戴尔笔记本电脑', 3);
INSERT INTO `tb_categorysecond` VALUES (7, '联想笔记本电脑', 3);
INSERT INTO `tb_categorysecond` VALUES (8, '神舟笔记本电脑', 3);
INSERT INTO `tb_categorysecond` VALUES (9, '小米电视', 4);
INSERT INTO `tb_categorysecond` VALUES (12, '小米路由器3', 6);
INSERT INTO `tb_categorysecond` VALUES (13, '小米笔记本', 3);

-- ----------------------------
-- Table structure for tb_customer
-- ----------------------------
DROP TABLE IF EXISTS `tb_customer`;
CREATE TABLE `tb_customer`  (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `password` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '密码',
  `realname` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '真实姓名',
  `sex` char(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '性别',
  `birthdate` date NULL DEFAULT NULL COMMENT '出生日期',
  `idcard` varchar(18) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '身份证号',
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `tel` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '电话',
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地址',
  `code` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮编',
  `status` int(1) UNSIGNED ZEROFILL NULL DEFAULT 0 COMMENT '账号状态',
  PRIMARY KEY (`uid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_customer
-- ----------------------------
INSERT INTO `tb_customer` VALUES (1, 'Kira', 'e10adc3949ba59abbe56e057f20f883e', '吉良', '男', '1997-02-23', '511322199002235011', '123456@shop.com', '18080808080', '中信大道二段一号成都工业学院', '611730', 0);
INSERT INTO `tb_customer` VALUES (2, 'Lisi', 'e10adc3949ba59abbe56e057f20f883e', '李四', '女', '1996-06-03', '511321199606033185', '123789@shop.com', '18080808080', '中信大道二段一号成都工业学院', '611730', 0);
INSERT INTO `tb_customer` VALUES (3, '张三', 'e10adc3949ba59abbe56e057f20f883e', '张三', '男', '1997-01-22', '501321199701225021', '789456@shop.com', '18080808080', '中信大道二段一号成都工业学院', '611730', 1);
INSERT INTO `tb_customer` VALUES (13, '1806831506', 'e10adc3949ba59abbe56e057f20f883e', '吉良', '女', '1997-01-22', '501321199701225021', 'hsrtty@outlook.com', '18080808080', '中信大道二段一号成都工业学院', '611730', 0);
INSERT INTO `tb_customer` VALUES (14, 'Sakvoi', 'e10adc3949ba59abbe56e057f20f883e', '吉良', '男', '1997-01-22', '501321199701225021', '123456@qq.com', '18080808080', '中信大道二段一号成都工业学院', '611730', 0);
INSERT INTO `tb_customer` VALUES (15, 'Sakvome', 'e10adc3949ba59abbe56e057f20f883e', '吉良', '男', '1997-01-22', '501321199701225021', '123456@qq.com', '18080808080', '中信大道二段一号成都工业学院', '611730', 0);
INSERT INTO `tb_customer` VALUES (16, 'Hashimoto', '4d430028a6cf42c8802d311c2ca7904b', '吉良', '男', '1997-01-22', '501321199701225021', '123456@qq.com', '18080808080', '中信大道二段一号成都工业学院', '611730', 0);

-- ----------------------------
-- Table structure for tb_order
-- ----------------------------
DROP TABLE IF EXISTS `tb_order`;
CREATE TABLE `tb_order`  (
  `oid` int(55) NOT NULL AUTO_INCREMENT,
  `totalprice` double NULL DEFAULT NULL,
  `orderdate` datetime NULL DEFAULT NULL,
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0',
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tel` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `uid` int(55) NULL DEFAULT NULL,
  PRIMARY KEY (`oid`) USING BTREE,
  INDEX `uid`(`uid`) USING BTREE,
  CONSTRAINT `uid` FOREIGN KEY (`uid`) REFERENCES `tb_customer` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_order
-- ----------------------------
INSERT INTO `tb_order` VALUES (1, 3099, '2019-01-10 10:32:34', '0', 'Alex', '18282028691', '成都工业学院', 1);
INSERT INTO `tb_order` VALUES (2, 9798, '2019-01-10 11:05:08', '0', 'Kira', '18282028691', '成都工业学院', 1);

-- ----------------------------
-- Table structure for tb_orderitem
-- ----------------------------
DROP TABLE IF EXISTS `tb_orderitem`;
CREATE TABLE `tb_orderitem`  (
  `itemid` int(55) NOT NULL AUTO_INCREMENT,
  `count` int(11) NULL DEFAULT NULL,
  `totalprice` double NULL DEFAULT NULL,
  `pid` int(55) NULL DEFAULT NULL,
  `oid` int(55) NULL DEFAULT NULL,
  PRIMARY KEY (`itemid`) USING BTREE,
  INDEX `pid`(`pid`) USING BTREE,
  INDEX `oid`(`oid`) USING BTREE,
  CONSTRAINT `oid` FOREIGN KEY (`oid`) REFERENCES `tb_order` (`oid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pid` FOREIGN KEY (`pid`) REFERENCES `tb_product` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_orderitem
-- ----------------------------
INSERT INTO `tb_orderitem` VALUES (1, 1, 3099, 1, 1);
INSERT INTO `tb_orderitem` VALUES (2, 1, 3099, 1, 2);
INSERT INTO `tb_orderitem` VALUES (3, 1, 6599, 2, 2);

-- ----------------------------
-- Table structure for tb_product
-- ----------------------------
DROP TABLE IF EXISTS `tb_product`;
CREATE TABLE `tb_product`  (
  `pid` int(55) NOT NULL AUTO_INCREMENT,
  `pname` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品名称',
  `marketprice` double NULL DEFAULT NULL COMMENT '市场价格',
  `storeprice` double NULL DEFAULT NULL COMMENT '商城价格',
  `image` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片地址',
  `descs` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '描述',
  `pdate` datetime NULL DEFAULT NULL COMMENT '日期',
  `pcode` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品编号',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '状态',
  `csid` int(50) NULL DEFAULT NULL,
  `sid` int(55) NULL DEFAULT NULL,
  PRIMARY KEY (`pid`) USING BTREE,
  INDEX `csid`(`csid`) USING BTREE,
  INDEX `sid`(`sid`) USING BTREE,
  CONSTRAINT `csid` FOREIGN KEY (`csid`) REFERENCES `tb_categorysecond` (`csid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `sid` FOREIGN KEY (`sid`) REFERENCES `tb_seller` (`sid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_product
-- ----------------------------
INSERT INTO `tb_product` VALUES (1, '小米 8', 3199, 3099, 'MI_8.jpg', '骁龙845', '2019-01-09 15:26:26', '100000177759', '0', 1, 1);
INSERT INTO `tb_product` VALUES (2, 'iPhone XR', 6599, 6499, 'iPhone_XR.jpg', '4G手机 双卡双待', '2018-09-10 10:45:34', '100000177758', '0', 4, 3);
INSERT INTO `tb_product` VALUES (3, '小米MIX2S', 3699, 3599, 'MI_MIX2S.jpg', '陶瓷机身 手机中的艺术品', '2019-01-09 18:16:58', '100000177760', '0', 1, 1);
INSERT INTO `tb_product` VALUES (4, '小米 8SE', 1999, 1699, 'MI_8SE.jpg', '三星 AMOLED 全面屏', '2019-01-09 18:20:23', '100000177761', '0', 1, 1);
INSERT INTO `tb_product` VALUES (5, 'iPhone 6S', 3149, 2699, 'iPhone_6S.jpg', '全网通4G手机', '2019-01-09 18:36:35', '100000177762', '0', 4, 3);
INSERT INTO `tb_product` VALUES (6, 'iPhone 7', 3899, 3899, 'iPhone_7.jpg', 'iPhone 7', '2019-01-09 18:38:07', '100000177763', '0', 4, 3);
INSERT INTO `tb_product` VALUES (7, '小米笔记本15.6寸', 3399, 3099, 'MI_NoteBook_15.jpg', '小米笔记本15.6吋', '2019-01-09 22:24:16', '100000177764', '0', 13, 1);
INSERT INTO `tb_product` VALUES (8, '小米笔记本电脑Air 12.5寸', 4299, 4299, 'MI_NoteBook_Air_12.5.jpg', '学生游戏电脑笔记本', '2019-01-09 22:35:42', '100000177765', '0', 13, 1);
INSERT INTO `tb_product` VALUES (9, '小米电视4A', 4499, 3699, 'MI_TV_4A.jpg', '4k超清智能网络电视', '2019-01-09 22:35:45', '100000177766', '0', 9, 1);
INSERT INTO `tb_product` VALUES (10, '红米6', 799, 729, 'Red_MI_6.jpg', '小屏高性能的双摄手机', '2019-01-10 20:34:35', '100000177767', '0', 1, 1);
INSERT INTO `tb_product` VALUES (11, '小米MIX 3', 4299, 4199, 'MI_MIX_3.jpg', '磁动力滑盖全面屏', '2019-01-10 22:08:41', '100000177767', '0', 1, 1);

-- ----------------------------
-- Table structure for tb_seller
-- ----------------------------
DROP TABLE IF EXISTS `tb_seller`;
CREATE TABLE `tb_seller`  (
  `sid` int(55) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `password` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '密码',
  `license` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '工商注册号',
  `company` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '公司名称',
  `scope` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '经营范围',
  PRIMARY KEY (`sid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_seller
-- ----------------------------
INSERT INTO `tb_seller` VALUES (1, '雷军', 'e10adc3949ba59abbe56e057f20f883e', '110108012660427', '小米科技有限公司', '技术开发；货物进出口；电子数码');
INSERT INTO `tb_seller` VALUES (2, '黄章', 'e10adc3949ba59abbe56e057f20f883e', '110108012660425', '魅族科技公司', '技术开发；货物进出口；电子数码');
INSERT INTO `tb_seller` VALUES (3, '库克', 'e10adc3949ba59abbe56e057f20f883e', '110108012660424', '苹果公司（Apple Inc. ）', '电脑硬件、电脑软件、消费电子产品、数字发布、零售');

SET FOREIGN_KEY_CHECKS = 1;
